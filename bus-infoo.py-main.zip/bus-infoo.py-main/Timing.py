import streamlit as st
st.title("Timing :mantelpiece_clock:")

st.subheader("Know the Timings of buses you want :dart:")
st.write("""
* Kurnool to Hyderabad :point_right:[k2h.list>](https://docs.google.com/spreadsheets/d/1Cts-Y6vJB_e55_YYZG_QUp3SzhmVQmehStqKdNWaxdk/edit?usp=sharing)
* Kurnool  to Bangalore:point_right:[k2b.list>](https://docs.google.com/spreadsheets/d/1vG5q_LBV-LhKcNnlHG9v6s9aHVuz14se6YGpf9G2alk/edit?usp=sharing)
* Kurnool to Tirupati :point_right:[k2t.list>](https://docs.google.com/spreadsheets/d/1Z0u5lpXS9tLtKOVISxjzjxqBFFwLbssayE7zh-sJSpQ/edit?usp=sharing)
* Kurnool to Vijayawada:point_right:[ktv.list>](https://docs.google.com/spreadsheets/d/1ictO8SNqlm27GCe8p0p7bS19fPHV-vCYNiVw6v6rcmM/edit?usp=sharing)""")
st.write("---")
st.write("May the timings can be delay but you can catch the bus with in or after 15-20 mins . We are assure you that be careful with online payment don't give or send money to unknown :thumbsup:")